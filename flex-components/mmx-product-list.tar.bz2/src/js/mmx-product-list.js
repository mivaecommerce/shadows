/**
 * MMX / PRODUCT LIST
 */
class MMX_ProductList extends MMX_Element {

	static get props() {
		return {
			'product-set': {
				options: [
					'auto',
					'all',
					'category',
					'merchandising',
					'related',
					'search'
				],
				default: 'auto'
			},
			'category-code': {
				allowAny: true
			},
			'product-code': {
				allowAny: true
			},
			'merchandisingshowcase-code': {
				allowAny: true
			},
			'merchandisingshowcase-context-product-id': {
				allowAny: true
			},
			'merchandisingshowcase-context-category-id': {
				allowAny: true
			},
			'search': {
				allowAny: true
			},
			'per-page': {
				allowAny: true,
				isNumeric: true,
				default: 24
			},
			'show-pagination': {
				isBoolean: true,
				default: true
			},
			'pagination-page-numbers': {
				options: [
					'dropdown',
					'links',
					'none'
				],
				default: 'links'
			},
			'pagination-page-link-count': {
				allowAny: true,
				isNumeric: true,
				default: 7
			},
			'pagination-next-previous': {
				options: [
					'arrows',
					'text',
					'none'
				],
				default: 'arrows'
			},
			'pagination-previous-text': {
				allowAny: true,
				default: 'Previous'
			},
			'pagination-next-text': {
				allowAny: true,
				default: 'Next'
			},
			'sort-by': {
				allowAny: true,
				default: 'disp_order',
			},
			'offset': {
				allowAny: true,
				isNumeric: true,
				default: 0
			},
			'submit-method': {
				options: [
					'replace',
					'reload'
				],
				default: 'replace'
			},
			'columns': {
				allowAny: true,
				default: '2,3,4'
			},
			'product-fallback-image': {
				allowAny: true
			},
			'adpr-url': {
				allowAny: true,
				default:  MMX.longMerchantUrl({Screen: 'BASK'})
			},
			'atwl-url': {
				allowAny: true,
				default:  MMX.longMerchantUrl({Screen: 'WISH'})
			},
			'show-facets': {
				isBoolean: true,
				default: true
			},
			'show-per-page': {
				isBoolean: true,
				default: true
			},
			'show-sort-by': {
				isBoolean: true,
				default: true
			},
			'expanded-facets': {
				options: [
					'expand_all',
					'expand_first_number',
					'collapse_all'
				],
				default: 'expand_all'
			},
			'expanded-facet-count': {
				allowAny: true,
				isNumeric: true,
				default: null
			},
			'show-facet-value-counts': {
				isBoolean: true,
				default: true
			},
			'facets-title': {
				allowAny: true,
				default: 'Filters'
			},
			'facets-title-theme': {
				allowAny: true,
				isBoolean: true,
				default: false
			},
			'facets-title-theme-class': {
				allowAny: true,
				default: ''
			},
			'facets-title-style': {
				allowAny: true,
				default: 'title-4'
			},
			'facets-title-styles': {
				allowAny: true,
				default: ''
			},
			'facets-width': {
				allowAny: true,
				isNumeric: true,
				default: 20
			},
			'facet-theme': {
				allowAny: true,
				isBoolean: true,
				default: false
			},
			'facet-theme-class': {
				allowAny: true,
				default: ''
			},
			'facet-style': {
				allowAny: true,
				default: 'subheading-s'
			},
			'facet-styles': {
				allowAny: true,
				default: ''
			},
			'show-details': {
				isBoolean: true,
				default: true
			},
			'show-detail-products' : {
				isBoolean: true,
				default: true
			},
			'show-detail-page' : {
				isBoolean: true,
				default: false
			},
			'show-detail-search' : {
				isBoolean: true,
				default: true
			},
			'product-show-image': {
				isBoolean: true,
				default: true
			},
			'product-image-type': {
				allowAny: true,
				default: 'main'
			},
			'product-image-dimensions': {
				allowAny: true,
				default: '350x350'
			},
			'product-image-fit': {
				allowAny: true,
				options: [
					'cover',
					'contain',
					'fill',
					'none',
					'scale-down'
				],
				default: 'contain'
			},
			'param-prefix': {
				allowAny: true
			},
			'empty-results-message': {
				allowAny: true
			},
			'empty-results-message-source': {
				allowAny: true
			},
			'show-empty-results' : {
				isBoolean: true,
				default: true
			},
			'show-category-tree': {
				isBoolean: true,
				default: false
			},
			'display-show-more-links': {
				isBoolean: true,
				default: true
			},
			'show-more-threshold': {
				allowAny: true,
				isNumeric: true,
				default: 8
			},
			'show-more-text': {
				allowAny: true,
				default: 'Show More'
			},
			'show-less-text': {
				allowAny: true,
				default: 'Show Less'
			},
			'hide-facets-on-desktop': {
				isBoolean: true,
				default: false
			},
			'show-facets-prefix': {
				allowAny: true,
				default: 'Show'
			},
			'hide-facets-prefix': {
				allowAny: true,
				default: 'Hide'
			}
		};
	}

	styleResourceCodes = ['mmx-base', 'mmx-text', 'mmx-accordion', 'mmx-forms', 'mmx-product-list'];
	renderUniquely = true;
	lifecycleReady = false;

	#products = [];
	#facets = [];
	#facetsOpened = false;
	#appliedFacetValueCount = 0;
	#card = {};
	#pagination = {};
	#sortByOptions = [];
	#perPageOptions = [];
	#searchOrigin = 'Runtime API';
	#searchType = 'system';
	#searchIndex = '';
	#commonParamsToExclude = ['Store_Code', 'Screen', 'Action', 'Per_Page', 'Sort_By', 'Offset', 'Search'];
	#paramPrefix;
	#desktopBreakpoint = window.matchMedia('(min-width: 60em)');
	#errorMessage;
	#debounceDelay = 500;

	constructor() {
		super();
		this.makeComponent();
		this.#bindComponentEvents();
	}

	// MMX_Element Render Life Cycle
	render() {
		if (!this.#shouldRender()) {
			return '';
		}

		let showFacets = this.getPropValue('show-facets');

		if (this.getPropValue('hide-facets-on-desktop')) {
			showFacets = this.#facetsOpened;
		}

		return /*html*/`
			<div
				part="wrapper"
				class="
					mmx-product-list
					has-facets--${MMX.encodeEntities(showFacets)}
					has-per-page--${MMX.encodeEntities(this.getPropValue('show-per-page'))}
					has-sort-by--${MMX.encodeEntities(this.getPropValue('show-sort-by'))}
					has-details--${MMX.encodeEntities(this.getPropValue('show-details'))}
					hide-facets-on-desktop--${MMX.encodeEntities(this.getPropValue('hide-facets-on-desktop'))}
				"
			>
				<div part="title" class="mmx-product-list__title">
					<slot name="title"></slot>
				</div>
				${this.#renderCategoryCarousel()}
				${this.#renderMain()}
				<div part="loading-overlay" class="mmx-product-list__loading-overlay"></div>
			</div>
		`;
	}

	#shouldRender() {
		if (this.#products.length) {
			return true;
		}

		return this.getPropValue('show-empty-results');
	}

	styles() {
		const columns = this.#getColumns();
		const facetsWidth = this.getPropValue('facets-width');
		const productsWidth = 100 - facetsWidth;

		return /*css*/`
			:host {
				--mmx-product-list__columns--mobile: ${columns.mobile};
				--mmx-product-list__columns--tablet: ${columns.tablet};
				--mmx-product-list__columns--desktop: ${columns.desktop};
				--mmx-product-list__facets-width: ${facetsWidth}fr ${productsWidth}fr;
			}
		`;
	}

	// Data Methods
	onDataChange() {
		this.#card = this.data.card;
		this.#sortByOptions = Array.from(this.data?.list?.sort_by?.options?.children ?? []);
		this.#perPageOptions = Array.from(this.data?.list?.per_page?.options?.children ?? []);
		this.#searchOrigin = this.data?.advanced?.search?.origin?.value ?? 'Runtime API';
		this.#searchType = this.data?.advanced?.search?.type?.value ?? 'system';
		this.#searchIndex = this.data?.advanced?.search?.index?.value ?? '';
		this.#facetsOpened = false;

		MMX.setElementAttributes(this, {
			'data-product-set': this.data?.list?.products?.product_set?.value,
			'data-category-code': this.data?.list?.products?.category?.category_code,
			'data-product-code': this.data?.list?.products?.product?.product_code,
			'data-merchandisingshowcase-code': this.data?.list?.products?.showcase?.code ?? this.data?.list?.products?.prompt?.code,
			'data-merchandisingshowcase-context-product-id': this.data?.list?.products?.showcase?.context?.product_id ?? this.data?.list?.products?.prompt?.context?.product_id,
			'data-merchandisingshowcase-context-category-id': this.data?.list?.products?.showcase?.context?.category_id ?? this.data?.list?.products?.prompt?.context?.category_id,
			'data-search': this.data?.server?.search,
			'data-show-sort-by': this.#sortByOptions.length > 0,
			'data-sort-by': MMX.concatenateSortBy(this.data?.list?.sort_by?.default?.value, this.data?.list?.sort_by?.default_customfield?.value),
			'data-show-per-page': this.#perPageOptions.length > 0,
			'data-per-page': this.data?.list?.per_page?.default?.value,
			'data-submit-method': this.data?.advanced?.submit_method?.value,
			'data-show-facets': this.data?.list?.facets?.settings?.enabled ?? false,
			'data-show-facet-value-counts': this.data?.list?.facets?.show_value_counts?.value,
			'data-show-pagination': this.data?.list?.pagination?.settings?.enabled ?? false,
			'data-pagination-page-numbers': this.data?.list?.pagination?.page_numbers?.value,
			'data-pagination-page-link-count': this.data?.list?.pagination?.page_link_count?.value,
			'data-pagination-next-previous': this.data?.list?.pagination?.next_previous?.value,
			'data-pagination-next-text': this.data?.list?.pagination?.next_text?.value,
			'data-pagination-previous-text': this.data?.list?.pagination?.previous_text?.value,
			'data-facets-title': this.data?.list?.facets?.title?.value,
			'data-facets-title-theme': this.data?.list?.facets?.title?.textsettings?.fields?.normal?.typography_theme?.theme_available,
			'data-facets-title-theme-class': this.data?.list?.facets?.title?.textsettings?.fields?.normal?.typography_theme?.classname,
			'data-facets-title-style': this.data?.list?.facets?.title?.textsettings?.fields?.normal?.title_style?.value,
			'data-facets-title-styles': this.data?.list?.facets?.title?.textsettings?.styles?.normal,
			'data-facets-width': this.data?.list?.facets?.width?.value,
			'data-facet-theme': this.data?.list?.facets?.facet_styles?.typography_theme?.theme_available,
			'data-facet-theme-class': this.data?.list?.facets?.facet_styles?.typography_theme?.classname,
			'data-facet-style': this.data?.list?.facets?.facet_styles?.facet_style?.value,
			'data-facet-styles': this.getStylesFromGroup(this.data?.list?.facets?.facet_styles),
			'data-columns': [
				MMX.coerceNumber(this.data?.list?.columns?.mobile?.value, 2),
				MMX.coerceNumber(this.data?.list?.columns?.tablet?.value, 3),
				MMX.coerceNumber(this.data?.list?.columns?.desktop?.value, 4)
			].join(','),
			'data-expanded-facets': this.data?.list?.facets?.expanded_facets?.value,
			'data-expanded-facet-count': this.data?.list?.facets?.expanded_facet_count?.value,
			'data-show-details': this.data?.list?.details?.settings?.enabled ?? false,
			'data-show-detail-products': this.data?.list?.details?.show_total_products?.value,
			'data-show-detail-page': this.data?.list?.details?.show_current_page?.value,
			'data-show-detail-search': this.data?.list?.details?.show_search_term?.value,
			'data-product-show-image': this.data?.card?.image?.settings?.enabled ?? false,
			'data-product-image-type': this.data?.card?.image?.type?.value,
			'data-product-image-dimensions': this.data?.card?.image?.dimensions?.value,
			'data-product-image-fit': this.data?.card?.image?.fit?.value,
			'data-product-fallback-image': this.data?.fallback_product_image,
			'data-param-prefix': this.data?.advanced?.param_prefix?.value,
			'data-empty-results-message': this.data?.advanced?.empty_results_message?.value,
			'data-empty-results-message-source': this.data?.advanced?.empty_results_message?.source,
			'data-show-empty-results': this.data?.advanced?.show_empty_results?.value,
			'data-show-category-tree': this.data?.list?.facets?.show_category_tree?.value,
			'data-display-show-more-links': this.data?.list?.facets?.display_show_more_links?.value,
			'data-show-more-threshold': this.data?.list?.facets?.show_more_threshold?.value,
			'data-show-more-text': this.data?.list?.facets?.show_more_text?.value,
			'data-show-less-text': this.data?.list?.facets?.show_less_text?.value,
			'data-hide-facets-on-desktop': this.data?.list?.facets?.hide_facets_on_desktop?.value,
			'data-show-facets-prefix': this.data?.list?.facets?.show_facets_prefix?.value,
			'data-hide-facets-prefix': this.data?.list?.facets?.hide_facets_prefix?.value,
			'data-add-to-wishlist-settings-provider': this.#addToWishlistEnabled() ? true : undefined
		});

		this.#setParamPrefix();
		this.#loadProducts();
	}

	// Events
	afterRender() {
		this.#replaceProducts();
		this.#bindEvents();
		this.#debouncedAfterRender();
	}

	#debouncedAfterRender = MMX.debounce(() => {
		this.#notifyProductsRendered();
	}, 100);

	#bindComponentEvents() {
		this.#desktopBreakpoint.addEventListener('change', () => this.#onDesktopBreakpointChange());

		history.scrollRestoration = 'manual';
		addEventListener('popstate', (e) => this.#onPopState(e));
	}

	#onDesktopBreakpointChange() {
		this.#handleOpenMobileFacet();
		this.#handleFacetDetails();
	}

	#handleOpenMobileFacet() {
		if (this.#desktopBreakpoint.matches) {
			this.#closeFacetsDialog();
		}
	}

	#handleFacetDetails() {
		if (this.#desktopBreakpoint.matches) {
			this.#restoreFacetDetails();
		} else {
			this.#closeFacetDetails();
		}
	}

	#restoreFacetDetails() {
		this.#facetDetails()?.forEach((detail, i) => {
			detail.open = this.#shouldFacetBeOpen(i);
		});
	}

	#bindEvents() {
		this.#facetsTitleButton()?.addEventListener?.('click', () => {
			this.#onFacetsTitleButtonClick();
		});

		this.#facetList()?.querySelectorAll('input, select')?.forEach(element => {
			element.addEventListener('input', () => this.#onManagedFacetInput());
		});

		this.#facetList()?.querySelectorAll('mmx-form-input-range')?.forEach(element => {
			element.addEventListener('input', () => this.#debouncedManagedFacetInput());
		});

		this.#managedDropdowns()?.forEach(dropdown => {
			dropdown.addEventListener('input', () => this.#onManagedDropdownInput(dropdown));
		});

		this.#managedLinks()?.forEach(link => {
			link.addEventListener('click', (e) => this.#onManagedLinkClick(e));
		});

		this.#facetValues()?.forEach(facetValue => {
			facetValue.addEventListener('click', (e) => this.#onFacetValueClick(e));
		});

		this.#facetsDialogOpen()?.addEventListener('click', () => {
			this.#onFacetsDialogOpenClick();
		});

		this.#facetsDialogClose()?.addEventListener('click', () => {
			this.#onFacetsDialogCloseClick();
		});

		this.on('click', '[part~="facets-dialog"]', this.#onFacetsDialogClick.bind(this));

		this.#productCards()?.forEach((product, index) => {
			product.addEventListener('click', () => this.#onProductClicked({
				product: this.#products[index],
				index
			}));
		});

		this.#facetShowMoreButtons()?.forEach(btn => {
			btn.addEventListener('click', (e) => this.#onFacetShowMoreButtonClick(btn, e));
		});
	}

	#onFacetsDialogClick(e, dialog) {
		const rect = dialog.getBoundingClientRect();
		const clickedInsideDialog =
			e.clientX >= rect.left &&
			e.clientX <= rect.right &&
			e.clientY >= rect.top &&
			e.clientY <= rect.bottom;

		if (!clickedInsideDialog) {
			this.#closeFacetsDialog();
		}
	}

	#facetShowMoreButtons() {
		return this.#facetList()?.querySelectorAll('.mmx-product-list__facet-values-toggle');
	}

	#onFacetShowMoreButtonClick(btn, e) {
		e.preventDefault();

		const facetCode = btn?.dataset?.facetCode;

		if (!facetCode) return;

		const isOpen = this.#toggleShowMoreFacetState(facetCode);

		this.#toggleFacetHiddenValues(facetCode, isOpen);
		this.#toggleShowMoreLessText(btn, isOpen);
	}

	#toggleShowMoreFacetState(facetCode) {
		if (this.#openShowMoreFacets.has(facetCode)) {
			this.#openShowMoreFacets.delete(facetCode);
			return false;
		}
		this.#openShowMoreFacets.add(facetCode);
		return true;
	}

	#toggleFacetHiddenValues(facetCode, isOpen) {
		const element = this.#facetList()?.querySelector(`.mmx-product-list__facet-values-hidden[data-facet-code="${facetCode}"]`);

		if (!element) return;

		if (isOpen) {
			this.#showHiddenFacetValues(element);
		} else {
			this.#hideHiddenFacetValues(element);
		}
	}

	#showHiddenFacetValues(element) {
		element.classList.add('is-open');
		element.setAttribute('aria-hidden', 'false');
		element.style.height = '0px';

		const targetHeight = element.scrollHeight;

		element.style.height = `${targetHeight}px`;

		const onOpenEnd = (e) => {
			if (e.propertyName !== 'height') return;
			element.removeEventListener('transitionend', onOpenEnd);
			element.style.height = 'auto';
		};

		element.addEventListener('transitionend', onOpenEnd);
		return;
	}

	#hideHiddenFacetValues(element) {
		element.setAttribute('aria-hidden', 'true');

		const startHeight = element.scrollHeight;

		element.style.height = `${startHeight}px`;
		element.offsetHeight;
		element.style.height = '0px';
		element.classList.remove('is-open');
	}

	#debouncedManagedFacetInput = MMX.debounce(() => {
		this.#onManagedFacetInput();
	}, this.#debounceDelay);

	#onManagedFacetInput() {
		this.#submit();
	}

	#managedDropdowns() {
		return this.shadowRoot.querySelectorAll('[part~="pagination-select-dropdown"], [part~="per-page-select-dropdown"], [part~="sort-by-select-dropdown"]');
	}

	#onManagedDropdownInput(dropdown) {
		const urlOptions = {};
		urlOptions[dropdown.name] = dropdown.value;

		const url = this.#getDestinationUrl(urlOptions);
		this.#submit(url);
	}

	#managedLinks() {
		return this.shadowRoot.querySelectorAll('[part~="pagination"] mmx-button, [part~="facet-applied-values"] mmx-button, [part~="clear-all"]');
	}

	#onManagedLinkClick(e) {
		e.preventDefault();
		this.#submit(e.currentTarget.getAttribute('href'));
	}

	// Details
	#getDataCardDetails() {
		const details = this.#card?.details?.children;
		return Array.isArray(details) ? details : [];
	}

	// Prop Methods
	#getColumns() {
		const columns = this.getPropValue('columns');

		let [mobile, tablet, desktop] = columns.split(',').map(column => {
			return MMX.coerceNumber(column, 1);
		});

		mobile = MMX.coerceNumber(mobile, 1);
		tablet = MMX.coerceNumber(tablet, mobile);
		desktop = MMX.coerceNumber(desktop, mobile);

		return {
			mobile,
			tablet,
			desktop
		};
	}

	#getProductSet() {
		const productSet = this.getPropValue('product-set');

		if (productSet === 'merchandising') {
			return 'merchandising';
		}

		if (productSet === 'related' || (productSet === 'auto' && this.getPropValue('product-code'))) {
			return 'related';
		}

		if (productSet === 'category' || (productSet === 'auto' && this.getPropValue('category-code'))) {
			return 'category';
		}

		if (productSet === 'search' || (productSet === 'auto' && !MMX.valueIsEmpty(this.#getSearch()))) {
			return 'search';
		}

		return 'all';
	}

	// Product List Load Query Methods
	#setLoading() {
		this.#container()?.classList?.add?.('is-loading');
	}

	#clearLoading() {
		this.#container()?.classList?.remove?.('is-loading');
	}

	#container() {
		return this.shadowRoot.querySelector('.mmx-product-list');
	}

	#loadProducts() {
		this.#products = [];
		this.#facets = [];
		this.#errorMessage = undefined;
		this.#clearPagination();
		this.#setLoading();

		MMX.Runtime_JSON_API_Call({
			params: this.#getListLoadQueryParams()
		})
		.then(response => {
			this.#productsLoaded(response);
		})
		.catch(response => {
			this.#productsFailedToLoad(response);
		})
		.finally(() => {
			this.#clearLoading();
		});
	}

	#productsLoaded(response) {
		this.#products = response.data.data;
		this.#initializeFacets(response.data.facets);
		this.#setPagination(response);
		this.forceUpdate();
		this.#notifyProductsLoaded();
	}

	#productsFailedToLoad(response) {
		this.#errorMessage = response.error_message;
		this.forceUpdate();
	}

	#notifyProductsRendered() {
		if (!this.#products?.length) {
			return;
		}

		this.#products.forEach(product => {
			window?.MivaEvents?.ThrowEvent?.('price_changed', {
				product_code: product.code,
				price: product.price,
				additional_price: product.base_price
			});
		});
	}

	#notifyProductsLoaded() {
		this.dispatchEvent(new CustomEvent('view_item_list', {
			bubbles: true,
			composed: true,
			detail: {
				item_list_id: this.id,
				item_list_name: this.data?.heading?.heading_text?.value,
				products: this.#products,
				element: this
			}
		}));
	}

	#onProductClicked({product, index} = {}) {
		this.#notifyProductClicked({product, index});
	}

	#notifyProductClicked({product, index} = {}) {
		product.index = index + 1;
		this.dispatchEvent(new CustomEvent('select_item', {
			bubbles: true,
			composed: true,
			detail: {
				item_list_id: this.id,
				item_list_name: this.data?.heading?.heading_text?.value,
				products: [product],
				element: this
			}
		}));
	}

	#getListLoadQueryParams() {
		return {
			function: this.#getListLoadQueryFunction(),
			count: this.#getPerPage(),
			sort: this.#getSortBy(),
			offset: this.#getOffset(),
			filter: this.#getListLoadQueryFilters(),
			product_code: this.getPropValue('product-code'),
			category_code: this.getPropValue('category-code'),
			...this.#getMerchandisingParams()
		};
	}

	#getListLoadQueryFunction() {
		const productSet = this.#getProductSet();

		if (productSet === 'category') {
			return 'Runtime_CategoryProductList_Load_Query';
		}

		if (productSet === 'related') {
			return 'Runtime_RelatedProductList_Load_Query';
		}

		if (productSet === 'merchandising') {
			return 'Runtime_MerchandisingProductList_Load_Query';
		}

		return 'Runtime_ProductList_Load_Query';
	}

	#getListLoadQueryFilters() {
		return [
			...this.#getDetailsFilters(),
			...this.#getImageFilters(),
			...this.#getSearchFilters(),
			...this.#getFacetFilters(),
			...this.#getAddToWishlistFilters(),
			...this.#getAttributeSwatchFilters(),
			...this.#getCacheKeysFilters()
		];
	}

	#getDetailsFilters() {
		const details = this.#getDataCardDetails();
		const filters = details.reduce((filters, detail) => {
			const type = detail?.type?.value;

			if (typeof type !== 'string') {
				return filters;
			}

			if (type === 'descrip') {
				filters.push({
					name: 'ondemandcolumns',
					value: ['descrip']
				});
			}

			if (type === 'customfield' && !MMX.valueIsEmpty(detail?.customfield?.value)) {
				filters.push({
					name: 'ondemandcolumns',
					value: [`CustomField_Values:${detail.customfield.value}`]
				});
			}

			if (type === 'rating') {
				const value = [];

				if (!MMX.valueIsEmpty(detail?.rating_settings?.rating_custom_field?.value)) {
					value.push(`CustomField_Values:${detail.rating_settings.rating_custom_field.value}`);
				}

				if (!MMX.valueIsEmpty(detail?.rating_settings?.count_custom_field?.value)) {
					value.push(`CustomField_Values:${detail.rating_settings.count_custom_field.value}`);
				}

				if (value.length) {
					filters.push({
						name: 'ondemandcolumns',
						value
					});
				}
			}

			if (type === 'fragment' && !MMX.valueIsEmpty(detail?.fragment?.value)) {
				filters.push({
					name: 'fragments',
					value: [detail.fragment.value]
				});
			}

			if (type === 'discounts') {
				filters.push({
					name: 'ondemandcolumns',
					value: ['discounts']
				});
			}

			if (type === 'price') {
				filters.push({
					name: 'ondemandcolumns',
					value: ['sale_price']
				});
			}

			if (['inv_short', 'inv_long', 'inv_available'].includes(type)) {
				filters.push({
					name: 'ondemandcolumns',
					value: ['inventory']
				});
			}

			return filters;
		}, []);

		return filters;
	}

	#getImageFilters() {
		if (!this.getPropValue('product-show-image')) {
			return [];
		}

		const productImageTypes = [this.getPropValue('product-image-type')];
		const hoverImageType = this.#card?.image?.hover_image?.type?.value;

		if (!MMX.valueIsEmpty(hoverImageType)) {
			productImageTypes.push(hoverImageType);
		}

		return [{
			name: 'imagetypes',
			value: {
				types: productImageTypes,
				sizes: ['original', this.getPropValue('product-image-dimensions')]
			}
		}];
	}

	#getSearchFilters() {
		const search = this.#getSearch();
		if (this.#getProductSet() === 'merchandising' || MMX.valueIsEmpty(search)) {
			return [];
		}

		return [{
			name: 'runtime_search',
			value: {
				search: search,
				origin: this.#searchOrigin,
				type: this.#searchType,
				index: this.#searchIndex
			}
		}];
	}

	#getFacetFilters() {
		if (!this.getPropValue('show-facets') && !this.#isCategoryCarouselEnabled()) {
			return [];
		}

		return [
			{
				name: 'ondemandcolumns',
				value: ['facets']
			},
			{
				name: 'facets',
				value: this.#getAppliedValuesFromUrl()
			}
		];
	}

	#getMerchandisingParams() {
		if (this.#getProductSet() !== 'merchandising') {
			return {};
		}

		const params = {
			MerchandisingShowcase_Code: this.getPropValue('merchandisingshowcase-code')
		};

		const productId = this.getPropValue('merchandisingshowcase-context-product-id');
		const categoryId = this.getPropValue('merchandisingshowcase-context-category-id');

		if (!MMX.valueIsEmpty(productId) || !MMX.valueIsEmpty(categoryId)) {
			params.Merchandising_Context = {
				product_id: productId,
				category_id: categoryId
			};
		}

		return params;
	}

	#getAppliedValuesFromUrl() {
		const values = {};
		const url = this.#getUrlFromLocation();

		url.searchParams.forEach((value, name) => {
			const unScopedName = this.#unScopeParam(name);

			if (this.#commonParamsToExclude.includes(unScopedName)) {
				return;
			}

			if (!this.#isScopedParam(name)) {
				return;
			}

			if (Array.isArray(values[unScopedName])) {
				values[unScopedName].push(value);
			} else {
				values[unScopedName] = [value];
			}
		});

		return values;
	}

	// Add to Wishlist
	getAddToWishlistSettings() {
		return this.#card?.add_to_wishlist ?? {};
	}

	#addToWishlistEnabled() {
		return MMX.isTruthy(this.getAddToWishlistSettings()?.settings?.enabled);
	}

	#getAddToWishlistFilters() {
		if (this.#addToWishlistEnabled()) {
			return [
				{
					name: 'ondemandcolumns',
					value: ['quantity_in_wishlists']
				}
			];
		}
		else {
			return [];
		}
	}

	// Attribute Swatches
	#getAttributeSwatchFilters() {
		if (MMX.isTruthy(this.#card?.image?.swatches?.settings?.enabled)) {
			return [
				{
					name: 'ondemandcolumns',
					value: ['attributes']
				}
			];
		}
		else {
			return [];
		}
	}

	#getCacheKeysFilters() {
		switch (this.#getProductSet()) {
			case 'category':
				return MMX.cacheKeysFilters(this.data?.list?.products?.category?.category);
			case 'related':
				return MMX.cacheKeysFilters(this.data?.list?.products?.product?.product);
			case 'merchandising':
				return MMX.cacheKeysFilters([
					this.data?.list?.products?.showcase,
					this.data?.list?.products?.showcase?.context?.product,
					this.data?.list?.products?.showcase?.context?.category
				]);
			default:
				return [];
		}
	}

	// Category Carousel
	#isCategoryCarouselEnabled() {
		return MMX.isTruthy(this.data?.list?.categories?.settings?.enabled);
	}

	#isCategoryFacet(facet) {
		return facet.code === 'category' && facet.module_code === 'stdfacets';
	}

	#getCategoryFacet() {
		return this.#facets.find(facet => this.#isCategoryFacet(facet));
	}

	#getCategoryFacetIds() {
		const facet = this.#getCategoryFacet();

		if (!facet?.values?.length) {
			return [];
		}

		return facet.values
			.map(value => parseInt(value.value.split('-')[0], 10))
			.filter(id => !isNaN(id) && id > 0);
	}

	#getMaxCategories() {
		const desktopPerPage = MMX.coerceNumber(MMX.splitString(this.data?.list?.categories?.per_page?.value)?.at?.(-1));
		return desktopPerPage * 2;
	}

	#renderCategoryCarousel() {
		if (!this.#isCategoryCarouselEnabled()) {
			return '';
		}

		const categoryIds = this.#getCategoryFacetIds().slice(0, this.#getMaxCategories());

		if (!categoryIds.length) {
			return '';
		}

		const categories = this.data?.list?.categories;
		const imageType = categories?.image_type?.value ?? 'cattree';
		const imageSize = parseInt(categories?.image_size?.value, 10);
		const scriptData = {
			category_group: {
				source: { value: 'ids' },
				categories: { ids: categoryIds },
				category_image: {
					image: { value: imageType },
					settings: { enabled: !MMX.valueIsEmpty(imageType) }
				},
				image_size: { value: imageSize > 0 ? `${imageSize}px` : undefined },
				image_fit: { value: categories?.image_fit?.value }
			},
			advanced: {
				slide_controls: {
					per_page: { value: categories?.per_page?.value },
					per_move: { value: categories?.per_move?.value }
				}
			}
		};

		const carouselInitialHeight = (imageSize > 0 ? imageSize : 0) + 24;

		return /*html*/`
			<div part="category-carousel" class="mmx-product-list__category-carousel">
				<mmx-category-carousel
					data-init="script"
					data-arrow-style="${MMX.encodeEntities(categories?.arrow_style?.value || 'button')}"
					data-nav-position="${MMX.encodeEntities(categories?.nav_position?.value || 'none')}"
					data-nav-button-size="${MMX.encodeEntities(categories?.nav_button_size?.value || '24')}"
					data-fallback-image="${MMX.encodeEntities(this.getPropValue('product-fallback-image'))}"
					style="--mmx-initial-height: ${carouselInitialHeight}px"
				>
					<script type="application/json">${MMX.scriptSafeJSONStringify(scriptData)}</script>
				</mmx-category-carousel>
			</div>
		`;
	}

	// Main
	#renderMain() {
		const totalProducts = this.#pagination?.totals?.products;
		const totalFacets = this.#facets?.length;

		if (this.#errorMessage) {
			return this.#renderMainError();
		}
		else if (totalProducts > 0 || totalFacets > 0) {
			return this.#renderMainValid();
		}
		else if (totalProducts === 0 && totalFacets === 0) {
			return this.#renderMainEmpty();
		}
		else {
			return this.#renderMainLoading();
		}
	}

	#renderMainValid() {
		return /*html*/`
			<div part="main" class="mmx-product-list__main">
				${this.#renderHeader()}
				${this.#renderProducts()}
				${this.#renderFooter()}
				${this.#renderFacets()}
			</div>
		`;
	}

	#renderMainError() {
		return /*html*/`
			<div part="error" class="mmx-product-list__error">
				<mmx-message data-style="warning">We're unable to display the products: ${MMX.encodeEntities(this.#errorMessage ?? 'There was a problem loading the products')}</mmx-message>
			</div>
		`;
	}

	#renderMainEmpty() {
		const message = this.getPropValue('empty-results-message');
		const source = this.getPropValue('empty-results-message-source');

		if (MMX.valueIsEmpty(message)) {
			return '';
		}

		return /*html*/`
			<div part="empty" class="mmx-product-list__empty">
				<mmx-message data-style="info">${source === 'markdown' ? message : MMX.encodeEntities(message)}</mmx-message>
			</div>
		`;
	}

	#renderMainLoading() {
		return /*html*/`
			<div part="loading" class="mmx-product-list__loading"></div>
		`;
	}

	// Header
	#renderHeader() {
		if (!this.getPropValue('show-facets') && !this.getPropValue('show-details') && !this.getPropValue('show-per-page') && !this.getPropValue('show-sort-by')) {
			return '';
		}

		return /*html*/`
			<div
				class="mmx-product-list__header"
				part="header"
			>
				${this.#renderFacetsDialogOpen()}
				${this.#renderFacetsTitleButton()}
				${this.#renderDetails()}
				${this.#renderPerPageSortBy({location: 'header'})}
			</div>
		`;
	}

	// List Details
	#renderDetails() {
		if (!this.getPropValue('show-details') || typeof this.#pagination?.totals === 'undefined') {
			return '';
		}

		const search = this.#getSearch();

		return /*html*/`
			<div part="details" class="mmx-product-list__details">
				${this.getPropValue('show-detail-search') && search?.length ? /*html*/`
					<div part="detail detail-search-term" class="mmx-product-list__detail">
						Search: "${MMX.encodeEntities(search)}"
					</div>
				` : ''}
				${this.getPropValue('show-detail-products') ? /*html*/`<div part="detail detail-total-products" class="mmx-product-list__detail">
					${MMX.encodeEntities(this.#pagination.totals.products)} ${MMX.pluralize('Item', this.#pagination.totals.products)}
				</div>` : ''}
				${this.getPropValue('show-detail-page') ? /*html*/`<div part="detail detail-current-page" class="mmx-product-list__detail">
					Page ${MMX.encodeEntities(this.#pagination.pages.current)} of ${MMX.encodeEntities(this.#pagination.pages.last)}
				</div>` : ''}
			</div>
		`;
	}

	#renderPerPageSortBy(options = {}) {
		if (!this.getPropValue('show-per-page') && !this.getPropValue('show-sort-by')) {
			return '';
		}

		return /*html*/`
			<div
				class="mmx-product-list__per-page-sort-by"
				part="per-page-sort-by"
			>
				${this.#renderPerPage(options)}
				${this.#renderSortBy(options)}
			</div>
		`;
	}

	// Per Page
	#renderPerPage({location} = {}) {
		if (!this.getPropValue('show-per-page')) {
			return '';
		}

		const encodedId = `per-page-select-dropdown--${MMX.encodeEntities(location)}`;

		return /*html*/`
			<div
				class="mmx-product-list__per-page"
				part="per-page"
			>
				<label
					class="mmx-form-label mmx-form-label--required"
					part="per-page-label"
					for="${encodedId}"
				>
					View:
				</label>
				<div
					class="mmx-form-select mmx-form-select--minimal"
					part="per-page-select"
				>
					<select
						name="Per_Page"
						class="mmx-form-select__dropdown"
						part="per-page-select-dropdown"
						id="${encodedId}"
						title="Products Per Page Options"
						required
					>
						${this.#perPageOptions.map(option => this.#renderPerPageOption(option)).join('')}
					</select>
				</div>
			</div>
		`;
	}

	#renderPerPageOption(option = {}) {
		const value = option?.amount?.value;
		const label = option?.label?.value;
		const selected = value == this.#getPerPage() ? 'selected' : '';
		return /*html*/`
			<option value="${MMX.encodeEntities(value)}" ${selected}>${label}</option>
		`;
	}

	// Sort By
	#sortValueLabelMap = {
		relevance: 'Relevance',
		disp_order: 'Display Order',
		disp_order_desc: 'Display Order Descending',
		newest: 'Newest',
		oldest: 'Oldest',
		updated: 'Recently Updated',
		code_asc: 'Code Ascending',
		code_desc: 'Code Descending',
		name_asc: 'Name Ascending',
		name_desc: 'Name Descending',
		price_asc: 'Price Ascending',
		price_desc: 'Price Descending',
		bestsellers: 'Best Sellers',
		customfield: 'Custom Field Ascending',
		customfield_desc: 'Custom Field Descending'
	};

	#renderSortBy({location} = {}) {
		if (!this.getPropValue('show-sort-by')) {
			return '';
		}

		const encodedId = `sort-by-select-dropdown--${MMX.encodeEntities(location)}`;

		return /*html*/`
			<div
				class="mmx-product-list__sort-by"
				part="sort-by"
			>
				<label
					class="mmx-form-label mmx-form-label--required"
					part="sort-by-label"
					for="${encodedId}"
				>
					Sort By:
				</label>
				<div
					class="mmx-form-select mmx-form-select--minimal"
					part="sort-by-select"
				>
					<select
						name="Sort_By"
						class="mmx-form-select__dropdown"
						part="sort-by-select-dropdown"
						id="${encodedId}"
						title="Sort By Options"
						required
					>
						${this.#sortByOptions.map(option => this.#renderSortByOption(option)).join('')}
					</select>
				</div>
			</div>
		`;
	}

	#renderSortByOption(option = {}) {
		const value = MMX.concatenateSortBy(option?.code?.value, option?.code_customfield?.value);
		const label = option?.label?.value ?? this.#sortValueLabelMap[value];
		const selected = value === this.#getSortBy() ? 'selected' : '';
		return /*html*/`
			<option value="${MMX.encodeEntities(value)}" ${selected}>${label}</option>
		`;
	}

	// Products
	#renderProducts() {
		return /*html*/`
			<div
				class="mmx-product-list__products"
				part="products"
			>
				${this.#pagination?.totals?.products > 0 ? /*html*/`<slot name="products"></slot>` : this.#renderMainEmpty()}
			</div>
		`;
	}

	#productsContainer() {
		return this.querySelector('[slot="products"]');
	}

	#replaceProducts() {
		this.renderContentIntoLightDomSlot({slotName: 'products', content: ''});
		this.#productsContainer()?.replaceChildren?.(this.#createProducts());
	}

	#createProducts() {
		if (!Array.isArray(this.#products)) {
			return '';
		}

		const parent = new DocumentFragment();
		const attributes = {
			'data-adpr-url': this.getPropValue('adpr-url'),
			'data-fallback-image': this.getPropValue('product-fallback-image'),
			'data-image-dimensions': this.getPropValue('product-image-dimensions'),
			'data-image-fit': this.getPropValue('product-image-fit'),
			'data-image-type': this.getPropValue('product-image-type'),
			'data-show-image': this.getPropValue('product-show-image'),
			'data-atwl-url': this.getPropValue('atwl-url')
		};

		const content = /*html*/`
			${this.renderThemeStylesheetTemplate(true)}
		`;

		this.#products.forEach(product => {
			attributes['data-product-code'] = product.code;
			MMX_ProductCard.create({
				product,
				card: this.#card,
				parent,
				attributes,
				content
			});
		});

		return parent;
	}

	#productCards() {
		return this.querySelectorAll('mmx-product-card');
	}

	// Product List Parameters
	#setParamPrefix() {
		const prefix = this.getPropValue('param-prefix');

		if (!MMX.valueIsEmpty(prefix)) {
			return this.#paramPrefix = prefix;
		}

		const productLists = document.querySelectorAll('mmx-product-list:not([data-param-prefix])');
		const myProductListIndex = Array.from(productLists).findIndex(productList => {
			return productList === this;
		});

		if (myProductListIndex <= 0) {
			return this.#paramPrefix = undefined;
		}

		return this.#paramPrefix = `ProductList${myProductListIndex}_`;
	}

	#scopeParam(param) {
		return this.#paramPrefix ? `${this.#paramPrefix}${param}` : param;
	}

	#unScopeParam(param) {
		if (!this.#paramPrefix) {
			return param;
		}

		const paramPattern = new RegExp(`^${this.#paramPrefix}`);
		return param.replace(paramPattern, '');
	}

	#isScopedParam(param) {
		return typeof this.#paramPrefix === 'undefined' || param.indexOf(this.#paramPrefix) === 0;
	}

	#getUrlFromLocation() {
		return new URL(window.location.href);
	}

	#buildUrlToSelf({Per_Page, Sort_By, Offset, omitFacets = false} = {}) {
		const url = this.#getUrlFromLocation();

		// Per Page
		const perPage = MMX.coerceNumber(Per_Page, this.#getPerPage());
		const perPageParam = this.#scopeParam('Per_Page');
		url.searchParams.delete(perPageParam);
		if (perPage !== this.getPropValue('per-page')) {
			url.searchParams.set(perPageParam, perPage);
		}

		// Sort By
		const sortBy = Sort_By ?? this.#getSortBy();
		const sortByParam = this.#scopeParam('Sort_By');
		url.searchParams.delete(sortByParam);
		if (sortBy !== this.getPropValue('sort-by')) {
			url.searchParams.set(sortByParam, sortBy);
		}

		// Offset
		const offset = MMX.coerceNumber(Offset, this.#getOffset());
		const offsetParam = this.#scopeParam('Offset');
		url.searchParams.delete(offsetParam);
		if (offset !== this.getPropValue('offset')) {
			url.searchParams.set(offsetParam, offset);
		}

		// Facets
		this.#facets.forEach(facet => {
			const facetParam = this.#scopeParam(facet.code);
			url.searchParams.delete(facetParam);

			if (omitFacets) {
				return;
			}

			facet.appliedValues.forEach(appliedValue => {
				url.searchParams.append(facetParam, appliedValue);
			});
		});

		return url;
	}

	#getDestinationUrl({Per_Page, Sort_By, Offset, omitFacets} = {}) {
		const url = this.#buildUrlToSelf({Per_Page, Sort_By, Offset, omitFacets});

		if (MMX.valueIsEmpty(Offset)) {
			url.searchParams.delete(this.#scopeParam('Offset'));
		}

		this.#facets.forEach(facet => {
			url.searchParams.delete(this.#scopeParam(facet.code));
		});

		const facetFormData = new FormData(this.#facetForm());

		for (const [facetCode, value] of facetFormData.entries()) {
			if (!this.#hasValidFacetValue({facetCode, value})) {
				continue;
			}

			url.searchParams.append(this.#scopeParam(facetCode), value);
		}

		return url;
	}

	#submit(url = this.#getDestinationUrl()) {
		if (this.getPropValue('submit-method') === 'replace') {
			this.#submitReplace(url);
			return;
		}

		this.#submitReload(url);
	}

	#submitReplace(url) {
		const state = {};

		if (this.hasAttribute('id')) {
			state[this.constructor.name] = this.id;
		}

		history.pushState(state, '', url);

		this.#scrollIntoView();
		this.#loadProducts();
	}

	#scrollIntoView() {
		this.scrollIntoView({
			behavior: 'smooth'
		});
	}

	#onPopState(e) {
		const shouldScrollIntoView = e.state?.[this.constructor.name] === this.id;

		if (shouldScrollIntoView) {
			this.#scrollIntoView();
		}

		this.#loadProducts();
	}

	#submitReload(url) {
		window.location = url;
	}

	#getParameter(name) {
		const url = this.#getUrlFromLocation();
		return url.searchParams.get(this.#scopeParam(name));
	}

	#getSortBy() {
		return this.#getParameter('Sort_By') ?? this.getPropValue('sort-by');
	}

	#getPerPage() {
		return MMX.coerceNumber(this.#getParameter('Per_Page') ?? this.getPropValue('per-page'));
	}

	#getOffset() {
		return MMX.coerceNumber(this.#getParameter('Offset') ?? this.getPropValue('offset'));
	}

	#getSearch() {
		return this.#getParameter('Search') ?? this.getPropValue('search');
	}

	// Footer
	#renderFooter() {
		if (!this.getPropValue('show-pagination')) {
			return '';
		}

		return /*html*/`
			<div
				class="mmx-product-list__footer"
				part="footer"
			>
				${this.#renderPagination()}
			</div>
		`;
	}

	// Pagination: State
	#clearPagination() {
		this.#pagination = {};
	}

	#setPagination(response) {
		const pagination = {
			perPage: this.#getPerPage(),
			pages: {},
			offsets: {},
			totals: {},
			links: []
		};

		pagination.totals.products = MMX.coerceNumber(response.data.total_count);
		pagination.totals.productsOnPage = MMX.coerceNumber(response?.data?.data?.length);
		pagination.totals.pages = Math.ceil(pagination.totals.products / pagination.perPage);

		pagination.offsets.current = MMX.coerceNumber(response.data.start_offset);

		pagination.offsets.next = pagination.offsets.current + pagination.perPage;
		pagination.offsets.next = pagination.offsets.next > pagination.totals.products ? null : pagination.offsets.next;

		pagination.offsets.previous = pagination.offsets.current - pagination.perPage;
		pagination.offsets.previous = pagination.offsets.previous < 0 ? null : pagination.offsets.previous;

		pagination.pages.first = 1;
		pagination.pages.last = pagination.totals.pages;

		pagination.pages.current = Math.floor((pagination.offsets.current / pagination.perPage) + 1);

		pagination.pages.isOnFirst = pagination.pages.current === pagination.pages.first;
		pagination.pages.isOnLast = pagination.pages.current === pagination.pages.last;

		pagination.pages.next = pagination.pages.current + 1;
		pagination.pages.next = pagination.pages.next > pagination.totals.pages ? null : pagination.pages.next;

		pagination.pages.previous = pagination.pages.current - 1;
		pagination.pages.previous = pagination.pages.previous < 1 ? null : pagination.pages.previous;

		pagination.links = {
			list: this.#buildPaginationLinks(pagination)
		};

		pagination.links.first = pagination.links.list.at(0);
		pagination.links.last = pagination.links.list.at(-1);

		pagination.links.previous = pagination.pages.previous === null ? null : pagination.links.list.at(pagination.pages.previous - 1);
		pagination.links.next = pagination.pages.next === null ? null : pagination.links.list.at(pagination.pages.next - 1);

		this.#pagination = pagination;
	}

	#buildPaginationLinks(pagination = {}) {
		const links = [];
		const linkCount = this.getPropValue('pagination-page-link-count');
		const linkCountPeek = Math.floor(linkCount / 2);
		let displayMin = Math.max(1, pagination.pages.current - linkCountPeek + 1);
		let displayMax = Math.min(pagination.pages.last, pagination.pages.current + linkCountPeek - 1);

		if (displayMin === 1) {
			displayMax = Math.min(pagination.pages.last, displayMin + linkCount - 2);
		}

		if (displayMax === pagination.pages.last) {
			displayMin = Math.max(1, displayMax - linkCount + 2);
		}

		for (let page = 1; page <= pagination.totals.pages; page++) {
			const link = {};

			link.page = page;
			link.isFirst = link.page === 1;
			link.isLast = link.page === pagination.pages.last;
			link.shouldDisplay = link.isFirst || link.isLast || (link.page >= displayMin && link.page <= displayMax);
			link.offset =  pagination.perPage * (page - 1);
			link.isCurrentPage = pagination.offsets.current === link.offset;

			link.url = this.#buildUrlToSelf();
			if (link.offset === 0) {
				link.url.searchParams.delete(this.#scopeParam('Offset'));
			} else {
				link.url.searchParams.set(this.#scopeParam('Offset'), link.offset);
			}

			link.suffix = link.isFirst && displayMin > 2 ? '...' : '';
			link.prefix = link.isLast && displayMax < (pagination.pages.last - 1) ? '...' : '';
			link.text = link.prefix + link.page + link.suffix;

			links.push(link);
		}

		return links;
	}

	#paginationSupported() {
		return this.getPropValue('show-pagination') && this.#hasMultiplePages();
	}

	#hasMultiplePages() {
		return MMX.coerceNumber(this.#pagination?.totals?.pages) > 1;
	}

	// Pagination: Dropdown
	#renderPagination() {
		if (!this.#paginationSupported()) {
			return '';
		}

		return /*html*/`
			<div
				class="mmx-product-list__pagination"
				part="pagination"
			>
				${this.#renderPaginationPreviousButton()}
				${this.#renderPaginationType()}
				${this.#renderPaginationNextButton()}
			</div>
		`;
	}

	#renderPaginationType(type = this.getPropValue('pagination-page-numbers')) {
		let links = '';

		if (type === 'dropdown') {
			links = this.#renderPaginationTypeDropdown();
		}
		else if (type === 'links') {
			links = this.#renderPaginationTypeLinks();
		}
		else {
			return '';
		}

		return /*html*/`
			<div
				part="pagination-page-numbers pagination-page-numbers-${MMX.encodeEntities(type)}"
			>
				${links}
			</div>
		`;
	}

	#renderPaginationTypeDropdown() {
		return /*html*/`
			<div
				class="mmx-form-select"
				part="pagination-select"
			>
				<select
					name="Offset"
					class="mmx-form-select__dropdown"
					part="pagination-select-dropdown"
					title="Pagination Current Page"
					required
				>
					${this.#renderPaginationOptions()}
				</select>
			</div>
		`;
	}

	#renderPaginationOptions() {
		let options = '';

		for (let index = 1; index <= this.#pagination.totals.pages; index++) {
			const offset = (index - 1) * this.#pagination.perPage;
			const selected = this.#pagination.offsets.current === offset ? 'selected' : '';
			const label = `Page ${index} of ${this.#pagination.totals.pages}`;

			options += /*html*/`<option value="${offset}" ${selected}>${label}</option>`;
		}

		return options;
	}

	#renderPaginationTypeLinks() {
		return this.#pagination.links.list.map(link => {
			if (!link.shouldDisplay) {
				return '';
			}

			return /*html*/`
				<mmx-button
					data-style="display-link"
					data-shape="round"
					href="${MMX.encodeEntities(link.url)}"
					class="mmx-product-list__pagination-page ${link.isCurrentPage ? 'hover' : ''}"
					part="pagination-page ${link.isCurrentPage ? 'pagination-page-current' : ''}"
				>
					${link.text}
				</mmx-button>
			`;
		}).join('');
	}

	// Pagination: Previous Button
	#renderPaginationPreviousButton() {
		const nextPreviousType = this.getPropValue('pagination-next-previous');

		if (nextPreviousType === 'none' || !this.#pagination.links.previous) {
			return '';
		}

		const text = this.getPropValue('pagination-previous-text');

		return /*html*/`
			<mmx-button
				part="pagination-previous"
				class="mmx-product-list__pagination-previous"
				data-style="display-link"
				data-shape="${nextPreviousType === 'arrows' ? 'round' : ''}"
				title="${MMX.encodeEntities(text)} Page"
				href="${MMX.encodeEntities(this.#pagination.links.previous.url)}"
			>
				${nextPreviousType === 'arrows' ? /*html*/`<mmx-icon part="pagination-previous-icon" data-name="chevron-left">${MMX.encodeEntities(text)} Page</mmx-icon>` : MMX.encodeEntities(text)}
			</mmx-button>
		`;
	}

	// Pagination: Next Button
	#renderPaginationNextButton() {
		const nextPreviousType = this.getPropValue('pagination-next-previous');

		if (nextPreviousType === 'none' || !this.#pagination.links.next) {
			return '';
		}

		const text = this.getPropValue('pagination-next-text');

		return /*html*/`
			<mmx-button
				part="pagination-next"
				class="mmx-product-list__pagination-next"
				data-style="display-link"
				data-shape="${nextPreviousType === 'arrows' ? 'round' : ''}"
				href="${MMX.encodeEntities(this.#pagination.links.next.url)}"
				title="${MMX.encodeEntities(text)} Page"
			>
				${nextPreviousType === 'arrows' ? /*html*/`<mmx-icon part="pagination-next-icon" data-name="chevron-right">${MMX.encodeEntities(text)} Page</mmx-icon>` : MMX.encodeEntities(text)}
			</mmx-button>
		`;
	}

	// Pagination: Methods
	goToPreviousPage() {
		this.goToPage(this.#pagination?.pages?.previous);
	}

	goToNextPage() {
		this.goToPage(this.#pagination?.pages?.next);
	}

	goToPage(page = 1) {
		if (!this.#paginationSupported() || isNaN(page)) {
			return;
		}

		if (page < 1) {
			page = 1;
		}

		if (page > this.#pagination.totals.pages) {
			page = this.#pagination.totals.pages;
		}

		const url = this.#pagination.links.list.at(page - 1)?.url;

		if (!url) {
			return;
		}

		this.#submit(url);
	}

	// Render: Facets
	#initializeFacets(facetObject = {}) {
		const facetArray = [];
		const url = this.#getUrlFromLocation();
		this.#appliedFacetValueCount = 0;

		for (const facetCode in facetObject) {
			const facet = facetObject[facetCode];
			facet.code = facetCode;

			facet.appliedValues = url.searchParams.getAll(this.#scopeParam(facet.code));
			facet.appliedValuesCount = facet.appliedValues.length;
			this.#appliedFacetValueCount += facet.appliedValuesCount;

			facet.applied = facet.applied_values?.reduce((applied, value, i) => {
				applied.push({
					value,
					prompt: facet.applied_prompts[i],
					selected: true
				});

				return applied;
			}, []) ?? [];

			facet.selectedValues = this.#determineSelectedValues({facet});

			facetArray.push(facet);
		}

		facetArray.sort((left, right) => {
			if (left.priority < right.priority)			return 1;
			else if	(left.priority > right.priority)	return -1;
			else if (left.name < right.name)			return -1;
			else if	(left.name > right.name)			return 1;
			else										return 0;
		});

		this.#facets = facetArray;
	}

	#determineSelectedValues({facet}) {
		if (facet.type !== 'rangeslider') {
			return facet?.values?.filter?.(facetValue => facetValue.selected);
		}

		if (facet.selected_value_low === 0 && facet.selected_value_high === 0) {
			return [];
		}

		const value = `${facet.selected_value_low}-${facet.selected_value_high}`;
		const prompt = facet.formatting === 'currency' ? `${MMCurrencyFormatter(facet.selected_value_low, true)} - ${MMCurrencyFormatter(facet.selected_value_high, true)}` : `${facet.selected_value_low} - ${facet.selected_value_high}`;

		return [{
			value,
			prompt
		}];
	}

	#hasValidFacetValue({facetCode, value} = {}) {
		const facet = this.#getFacetByCode(facetCode);

		if (!facet) {
			return false;
		}

		if (facet.type === 'rangeslider') {
			return this.#hasValidRangeFacetValue({facet, value});
		}

		return !MMX.valueIsEmpty(value);
	}

	#hasValidRangeFacetValue({facet, value} = {}) {
		if (value === '0-0') {
			return false;
		}

		const defaultMinMaxValue = `${facet.value_low}-${facet.value_high}`;
		if (value === defaultMinMaxValue) {
			return false;
		}

		return !MMX.valueIsEmpty(value);
	}

	#getFacetByCode(code) {
		return this.#facets.find(facet => {
			return facet.code === code;
		});
	}

	#facetForm() {
		return this.shadowRoot.querySelector('[part~="facets-form"]');
	}

	#renderFacets() {
		if (!this.getPropValue('show-facets') && !this.getPropValue('show-per-page') && !this.getPropValue('show-sort-by')) {
			return '';
		}

		return /*html*/`
			<dialog
				part="facets facets-dialog"
				class="mmx-product-list__facets mmx-product-list__facets-dialog"
			>
				<form
					part="facets-form"
					class="mmx-product-list__facets-form"
				>
					${this.#renderFacetsHeader()}
					${this.#renderPerPageSortBy({location: 'facets-dialog'})}
					${this.#renderAppliedFacets()}
					${this.#renderFacetsList()}
					${this.#renderCategoryTree()}
				</form>
				<mmx-button
					part="facets-dialog-close"
					class="mmx-product-list__facets-dialog-close"
					data-style="display-link"
					data-shape="round"
					title="Close Dialog?"
				>
					<mmx-icon>cross</mmx-icon>
				</mmx-button>
			</dialog>
		`;
	}

	#facetsDialog() {
		return this.shadowRoot.querySelector('[part~="facets-dialog"]');
	}

	#renderFacetsDialogOpen() {
		if (!this.getPropValue('show-facets') && !this.getPropValue('show-per-page') && !this.getPropValue('show-sort-by')) {
			return '';
		}

		return /*html*/`
			<mmx-button
				data-style="secondary"
				data-size="xs"
				part="facets-dialog-open"
				class="mmx-product-list__facets-dialog-open"
			>
				<mmx-icon>controls</mmx-icon>
				${MMX.encodeEntities(this.getPropValue('facets-title'))}
			</mmx-button>
		`;
	}

	#facetsDialogOpen() {
		return this.shadowRoot.querySelector('[part~="facets-dialog-open"]');
	}

	#onFacetsDialogOpenClick() {
		this.#openFacetsDialog();
	}

	#openFacetsDialog() {
		this.#facetsDialog()?.showModal();
	}

	#facetsDialogClose() {
		return this.shadowRoot.querySelector('[part~="facets-dialog-close"]');
	}

	#onFacetsDialogCloseClick() {
		this.#closeFacetsDialog();
	}

	#closeFacetsDialog() {
		this.#facetsDialog()?.close();
	}

	#facetDetails() {
		return this.shadowRoot.querySelectorAll('[part~="facets"] details');
	}

	#closeFacetDetails() {
		this.#facetDetails()?.forEach(detail => {
			detail.open = false;
		});
	}

	// Render: Facets Header
	#renderFacetsHeader({withPrefix = false} = {}) {
		const theme_available = this.getPropValue('facets-title-theme');

		return /*html*/`
			<div
				class="mmx-product-list__facets-header"
				part="facets-header"
			>
				${this.#renderFacetsTitle({withPrefix})}
				${this.#renderClearAllFacetsLink()}
			</div>
		`;
	}

	#renderFacetsTitle({withPrefix = false} = {}) {
		const theme_available = this.getPropValue('facets-title-theme');

		return /*html*/`
			<mmx-text
				class="mmx-product-list__facets-title"
				part="facets-title"
				data-theme="${MMX.encodeEntities(theme_available)}"
				data-theme-class="${MMX.encodeEntities(this.getPropValue('facets-title-theme-class'))}"
				data-style="${MMX.encodeEntities(this.getPropValue('facets-title-style'))}"
			>
				${this.renderLegacyStylesTemplate(theme_available, this.getPropValue('facets-title-styles'))}
				${this.renderThemeStylesheetTemplate(theme_available)}
				${withPrefix ? /*html*/`
					<mmx-icon>controls</mmx-icon>
					<span
						class="mmx-product-list__facets-title-prefix"
						data-show-facets-prefix="${MMX.encodeEntities(this.getPropValue('show-facets-prefix'))}"
						data-hide-facets-prefix="${MMX.encodeEntities(this.getPropValue('hide-facets-prefix'))}"
					></span>
				` : ''}
				${MMX.encodeEntities(this.getPropValue('facets-title'))}
			</mmx-text>
		`;
	}

	#renderFacetsTitleButton() {
		if (!this.getPropValue('hide-facets-on-desktop')) {
			return '';
		}

		return /*html*/`
			<button
				type="button"
				class="mmx-product-list__facets-title-button"
				part="facets-title-button"
			>
				${this.#renderFacetsTitle({withPrefix: true})}
			</button>
		`;
	}

	#facetsTitleButton() {
		return this.shadowRoot.querySelector('[part~="facets-title-button"]');
	}

	#onFacetsTitleButtonClick() {
		this.#toggleDesktopFacetLayout();
	}

	#toggleDesktopFacetLayout() {
		if (!this.getPropValue('show-facets')) {
			return;
		}

		const wrapper = this.shadowRoot.querySelector('[part~="wrapper"]');

		if (wrapper.classList.contains('has-facets--false')) {
			this.#facetsOpened = true;
			wrapper.classList.replace('has-facets--false', 'has-facets--true');
		} else {
			this.#facetsOpened = false;
			wrapper.classList.replace('has-facets--true', 'has-facets--false');
		}
	}

	#renderClearAllFacetsLink() {
		if (this.#appliedFacetValueCount === 0) {
			return '';
		}

		const url = this.#buildUrlToSelf({Offset: 0, omitFacets: true});

		return /*html*/`
			<mmx-button
				part="clear-all"
				class="mmx-product-list__clear-all"
				data-style="secondary-link"
				href="${MMX.encodeEntities(url)}"
			>
				<mmx-icon data-size="0.75em" data-name="cross"></mmx-icon> Clear All
			</mmx-button>
		`;
	}

	// Render: Applied Facets
	#renderAppliedFacets() {
		const appliedFacets = this.#facets.map(facet => this.#renderAppliedFacet(facet)).join('');

		if (MMX.valueIsEmpty(appliedFacets)) {
			return '';
		}

		return /*html*/`
			<div
				class="mmx-product-list__facet-applied-values"
				part="facet-applied-values"
			>
				${appliedFacets}
			</div>
		`;
	}

	#renderAppliedFacet(facet = {}) {
		return facet.selectedValues.map(facetValue => {
			return this.#renderAppliedFacetValue({facet, facetValue});
		}).join('');
	}

	#renderAppliedFacetValue({facet, facetValue} = {}) {
		const clearFacetUrl = this.#getUrlToClearFacet({facet, facetValue});

		return /*html*/`
			<mmx-button
				data-style="pill"
				title='Remove "${MMX.encodeEntities(facetValue.prompt)}"?'
				href="${MMX.encodeEntities(clearFacetUrl)}"
			>
				<mmx-icon data-size="0.75em" data-name="cross"></mmx-icon>
				${facetValue.prompt}
			</mmx-button>
		`;
	}

	#getUrlToClearFacet({facet, facetValue} = {}) {
		const removeUrl = this.#buildUrlToSelf({Offset: 0});
		removeUrl.searchParams.delete(this.#scopeParam(facet?.code), facetValue?.value);
		return removeUrl;
	}

	#facetList() {
		return this.shadowRoot.querySelector('[part~="facet-list"]');
	}

	#renderFacetsList() {
		return /*html*/`
			<mmx-accordion
				part="facet-list"
				class="mmx-product-list__facet-list"
				data-border-location="underline"
				data-icon-location="right"
			>
				${this.#facets.map((facet, facetIndex) => {
					return this.#renderFacet(facet, facetIndex);
				}).join('')}
			</mmx-accordion>
		`;
	}

	// Render: Facet
	#renderFacet(facet = {}, facetIndex = 0) {
		const theme_available = this.getPropValue('facet-theme');
		const open = this.#shouldFacetBeOpen(facetIndex);

		return /*html*/`
			<details
				slot="details"
				part="facet facet--${MMX.encodeEntities(facet.code)}"
				class="mmx-product-list__facet mmx-accordion__details"
				${open ? 'open' : ''}
			>
				<summary class="mmx-accordion__heading">
					<mmx-text
						class="mmx-product-list__facet-title mmx-accordion__heading-text"
						part="facet-title"
						data-theme="${MMX.encodeEntities(theme_available)}"
						data-theme-class="${MMX.encodeEntities(this.getPropValue('facet-theme-class'))}"
						data-style="${MMX.encodeEntities(this.getPropValue('facet-style'))}"
					>
						${this.renderLegacyStylesTemplate(theme_available, this.getPropValue('facet-styles'))}
						${this.renderThemeStylesheetTemplate(theme_available)}
						${facet?.name}
					</mmx-text>
					<mmx-icon
						class="mmx-accordion__heading-icon-open"
						data-name="subtract"
					></mmx-icon>
					<mmx-icon
						class="mmx-accordion__heading-icon-closed"
						data-name="add"
					></mmx-icon>
				</summary>
				<div class="mmx-accordion__content">
					${this.#renderFacetValuesByType(facet)}
				</div>
			</details>
		`;
	}

	#shouldFacetBeOpen(facetIndex) {
		const expandedFacets = this.getPropValue('expanded-facets');
		const expandedFacetCount = MMX.coerceNumber(this.getPropValue('expanded-facet-count'));

		if (expandedFacets === 'collapse_all') {
			return false;
		}

		if (expandedFacets === 'expand_first_number' && ((facetIndex + 1) > expandedFacetCount)) {
			return false;
		}

		return true;
	}

	#renderFacetValuesByType(facet) {
		if (facet.type === 'select') {
			return this.#renderFacetValuesSelect(facet);
		}

		if (facet.type === 'nested') {
			return this.#renderFacetValuesNested(facet);
		}

		if (facet.type === 'rangeslider') {
			return this.#renderFacetValueRange(facet);
		}

		return this.#renderFacetValuesControls(facet);
	}

	// Radio/Checkbox Facet
	#renderFacetValuesControls(facet) {
		return /*html*/`
			<fieldset
				class="mmx-product-list__facet-values mmx-form-fieldset"
				part="facet-values facet-values-list"
			>
				${this.#renderShowMoreFacetValues({ facet, facetValues: facet?.values ?? [] })}
			</fieldset>
		`;
	}

	#renderShowMoreFacetValues({ facet, facetValues, depth = 0 }) {
		const displayShowMoreLinks = this.getPropValue('display-show-more-links');
		const showMoreThreshold = MMX.coerceNumber(this.getPropValue('show-more-threshold'));
		const facetCode = facet?.code ?? '';

		const showMoreOpen = this.#openShowMoreFacets.has(facetCode);

		let visibleFacetValues = facetValues;
		let hiddenFacetValues = [];

		if (displayShowMoreLinks && showMoreThreshold > 0 && facetValues.length > showMoreThreshold) {
			visibleFacetValues = facetValues.slice(0, showMoreThreshold);
			hiddenFacetValues = facetValues.slice(showMoreThreshold);
		}

		const hasHidden = hiddenFacetValues.length > 0;

		return /*html*/`
			${visibleFacetValues.map(facetValue => this.#renderFacetValueControl({ facet, facetValue, depth })).join('')}

			${hasHidden ? /*html*/`
				<div
					class="mmx-form-fieldset mmx-product-list__facet-values-hidden ${showMoreOpen ? 'is-open' : ''}"
					part="facet-values facet-values-hidden"
					data-facet-code="${facetCode}"
					aria-hidden="${showMoreOpen ? 'false' : 'true'}"
					style="height:${showMoreOpen ? 'auto' : '0px'};"
				>
					${hiddenFacetValues.map(facetValue => this.#renderFacetValueControl({ facet, facetValue, depth })).join('')}
				</div>

				<mmx-button
					data-style="secondary-link"
					class="mmx-product-list__facet-values-toggle"
					part="facet-values facet-values-toggle"
					data-facet-code="${facetCode}"
					aria-expanded="${showMoreOpen ? 'true' : 'false'}"
				>
					${showMoreOpen ? MMX.encodeEntities(this.getPropValue('show-less-text')) : MMX.encodeEntities(this.getPropValue('show-more-text'))}
				</mmx-button>
			` : ''}
		`;
	}

	#toggleShowMoreLessText(btn, isOpen) {
		btn.textContent = isOpen ? this.getPropValue('show-less-text') : this.getPropValue('show-more-text');
		btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
	}

	#openShowMoreFacets = new Set();

	#renderFacetValueControl({facet, facetValue, depth = 0} = {}) {
		const controlType = facet.type === 'radio' ? 'radio' : 'checkbox';
		const checked = facetValue.selected ? 'checked' : '';
		depth = MMX.coerceNumber(depth);

		return /*html*/`
			<label
				class="mmx-product-list__facet-value mmx-form-${controlType}"
				part="facet-value"
				style="--mmx-product-list__facet-value-depth: ${depth};"
				data-depth="${depth}"
			>
				<input
					type="${controlType}"
					class="mmx-form-${controlType}__input"
					name="${MMX.encodeEntities(facet.code)}"
					value="${MMX.encodeEntities(facetValue.value)}"
					${checked}
				>
				<span class="mmx-form-caption mmx-form-${controlType}__caption">${facetValue.prompt}</span>
				${this.#renderFacetValueCount(facetValue)}
			</label>
		`;
	}

	#renderFacetValueCount(facetValue) {
		if (!this.getPropValue('show-facet-value-counts') || isNaN(facetValue?.count)) {
			return '';
		}

		return /*html*/`
			<span part="facet-value-count" class="mmx-product-list__facet-value-count">(${facetValue.count})</span>
		`;
	}

	#facetValues() {
		return this.shadowRoot.querySelectorAll('[part~="facet-value"]');
	}

	#onFacetValueClick(e) {
		this.#uncheckNestedFacetValues(e.currentTarget);
	}

	#uncheckNestedFacetValues(facetValue) {
		const currentDepth = MMX.coerceNumber(facetValue?.dataset?.depth);
		const nextFacetValue = facetValue?.nextElementSibling;
		const nextDepth = MMX.coerceNumber(nextFacetValue?.dataset?.depth);
		const nextCheckbox = nextFacetValue?.querySelector('[type="checkbox"]');

		if (nextDepth > currentDepth && nextCheckbox.checked) {
			nextCheckbox.checked = false;
			this.#uncheckNestedFacetValues(nextFacetValue);
		}
	}

	// Select Facet
	#renderFacetValuesSelect(facet) {
		return /*html*/`
			<div
				class="mmx-product-list__facet-values mmx-form-select"
				part="facet-values facet-values-select"
			>
				<select
					name="${MMX.encodeEntities(facet.code)}"
					class="mmx-form-select__dropdown"
					part="facet-values facet-values-select-dropdown"
					title="${MMX.encodeEntities(facet.name)} Facet Options"
				>
					<option value="">&lt;Select One&gt;</option>
					${facet?.values?.map(facetValue => this.#renderFacetValuesSelectOption({facet, facetValue})).join('')}
				</select>
			</div>
		`;
	}

	#renderFacetValuesSelectOption({facet, facetValue} = {}) {
		const selected = facetValue.selected ? 'selected' : '';

		return /*html*/`<option value="${MMX.encodeEntities(facetValue.value)}" ${selected}>${facetValue.prompt}</option>`;
	}

	// Nested Facet
	#renderFacetValuesNested(facet) {
		return /*html*/`
			<div
				class="mmx-product-list__facet-values mmx-form-fieldset"
				part="facet-values facet-values-nested"
			>
				${this.#renderFacetValuesNestedApplied({facet})}
				${this.#renderFacetValuesNestedUnapplied({facet})}
			</div>
		`;
	}

	#renderFacetValuesNestedApplied({facet}) {
		return facet.applied.map((facetValue, depth) => {
			return this.#renderFacetValueControl({
				facet,
				facetValue,
				depth
			});
		}).join('');
	}

	#renderFacetValuesNestedUnapplied({facet}) {
		return this.#renderShowMoreFacetValues({
			facet,
			facetValues: facet?.values ?? [],
			depth: facet.appliedValuesCount
		});
	}

	#renderFacetValueRange(facet) {
		const low = facet.selected_value_low || facet.value_low;
		const high = facet.selected_value_high || facet.value_high;
		const formatter = facet.formatting === 'currency' ? 'MMCurrencyFormatter' : '';

		return /*html*/`
			<div
				class="mmx-product-list__facet-values"
				part="facet-values facet-values-range"
			>
				<mmx-form-input-range
					data-name="${MMX.encodeEntities(facet.code)}"
					data-min="${MMX.encodeEntities(facet.value_low)}"
					data-max="${MMX.encodeEntities(facet.value_high)}"
					data-low="${MMX.encodeEntities(low)}"
					data-high="${MMX.encodeEntities(high)}"
					data-formatter="${formatter}"
				>
				</mmx-form-input-range>
			</div>
		`;
	}

	// Category Tree
	#renderCategoryTree() {
		if (!this.getPropValue('show-category-tree')) {
			return '';
		}

		return /*html*/`
			<slot part="category-tree" name="category-tree"></slot>
		`;
	}
}

if (!customElements.get('mmx-product-list')) {
	customElements.define('mmx-product-list', MMX_ProductList);
}