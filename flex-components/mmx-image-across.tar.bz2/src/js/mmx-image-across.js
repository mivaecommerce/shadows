/**
 * MMX / IMAGE ACROSS
 */
class MMX_ImageAcross extends MMX_Element {
	#auto_image_ratio;
	#scroll_position;
	#resize_observer;
	#intersection_observer;

	static get props() {
		return {
			align: {
				options: [
					'left',
					'center',
					'right'
				],
				default: 'center'
			},
			size: {
				options: [
					'auto',
					's',
					'm',
					'l'
				],
				allowAny: true,
				default: 'auto'
			},
			images: {
				allowAny: true,
				default: null
			},
			columns: {
				options: [
					'auto',
					'1',
					'2',
					'3',
					'4',
					'5',
					'6',
					'7',
					'8'
				],
				allowAny: true,
				default: 'auto',
				max: 8
			},
			overflow: {
				options: [
					'scroll',
					'wrap'
				],
				default: 'scroll'
			}
		};
	}

	styleResourceCodes = ['mmx-base', 'mmx-button', 'mmx-hero', 'mmx-image-across'];

	constructor() {
		super();
		this.makeComponent();
		this.#auto_image_ratio		= '';
		this.#scroll_position		= 0;
		this.#resize_observer		= new ResizeObserver(entries => this.setScrollPosition());
		this.#intersection_observer	= new IntersectionObserver(entries => {this.calculateScrollPosition();}, { rootMargin: '100% 0%', threshold: 0 });
		this.#bindComponentEvents();
	}

	#bindComponentEvents() {
		const breakpoints = [
			window.matchMedia('(min-width: 60em)'),
			window.matchMedia('(min-width: 40em)')
		];

		breakpoints.forEach(breakpoint =>
			breakpoint.addEventListener('change', this.#onBreakpointChange)
		);
	}

	#onBreakpointChange = () => {
		this.setImageHeight();
	};

	render() {
		return /*html*/`
			<div part="wrapper" class="mmx-image-across">
				<div part="title" class="mmx-image-across__title">
					<slot name="title"></slot>
				</div>
				<div part="images" class="mmx-image-across__images mmx-image-across__images-columns--${this.maxColumns()} mmx-image-across__images-overflow--${this.getPropValue('overflow')}">
					${this.renderImages()}
					<slot name="image"></slot>
				</div>
			</div>
		`;
	}

	afterRender() {
		this.setImageHeight();
		this.#resize_observer.observe(this.shadowImagesContainer());
		this.slottedImages().forEach(image => {this.#intersection_observer.observe(image);});
	}

	styles() {
		return /*css*/`
			:host {
				--mmx-image-across__text-align: ${this.getPropValue('align')};
				--mmx-image-across__columns: ${this.maxColumns()};
				--mmx-image-across__image-count: ${this.getImageCount()};
			}
		`;
	}

	images() {
		return this.loadPropertyData('images') || [];
	}

	slottedImages() {
		return this.querySelectorAll(':scope > [slot="image"]');
	}

	shadowImages() {
		return this.shadowRoot.querySelectorAll('[part="image"]');
	}

	shadowImagesContainer() {
		return this.shadowRoot.querySelector('[part="images"]');
	}

	imageElements() {
		return [...this.shadowImages(), ...this.slottedImages()];
	}

	renderImages() {
		return this.images().map((image => {
			return this.createElement({
				type: 'mmx-hero',
				attributes: {
					part: 'image',
					...image
				}
			}).outerHTML;
		})).join('');
	}

	getImageCount() {
		const slottedImageCount = this.slottedImages().length;
		return this.images().length + slottedImageCount;
	}

	maxColumns() {
		const columns = this.getPropValue('columns');

		if (columns !== 'auto') {
			return isNaN(columns) ? columns : Number(columns);
		}

		const imageCount = this.getImageCount();
		if (imageCount < this.constructor.props.columns.max) {
			return imageCount;
		}

		return this.constructor.props.columns.max;
	}

	getSize() {
		const size = this.getPropValue('size');
		if (size === 'auto') {
			return this.#auto_image_ratio;
		} else {
			return size;
		}
	}

	setImageHeight() {
		if (this.getPropValue('size') !== 'auto') {
			this.updateImageHeight(this.getPropValue('size'));
			return;
		}

		this.#bindImageLoadEvents();
		this.#updateRenderStatus();

		const ratio = this.#flattestImageRatio();

		if (!ratio) {
			return;
		}

		this.#auto_image_ratio = ratio;
		this.updateImageHeight(ratio);
	}

	#bindImageLoadEvents() {
		this.imageElements().forEach(image => {
			image.addEventListener('img:load', this.#event_image_load);
		});
	}

	#event_image_load = () => {
		this.setImageHeight();
	};

	#flattestImageRatio() {
		const dimensions = this.imageElements().map(image => this.#naturalImageDimensions(image));

		if (!dimensions.length || dimensions.some(dimension => !dimension)) {
			return '';
		}

		const flattest = dimensions.reduce((min, dimension) => {
			return (dimension.height / dimension.width) < (min.height / min.width) ? dimension : min;
		});

		return `${flattest.width}/${flattest.height}`;
	}

	#naturalImageDimensions(image) {
		const img = image?.slottedImage?.() ?? image?.shadowImage?.();

		if (!img) {
			return null;
		}

		const source = this.#visiblePictureSource(img.closest('picture'));
		const width = Number(source?.getAttribute('width') ?? img.getAttribute('width')) || img.naturalWidth;
		const height = Number(source?.getAttribute('height') ?? img.getAttribute('height')) || img.naturalHeight;

		if (!(width > 0) || !(height > 0)) {
			return null;
		}

		return {width, height};
	}

	#visiblePictureSource(picture) {
		if (!picture) {
			return null;
		}

		return [...picture.querySelectorAll('source[media]')].find(source => {
			return window.matchMedia(source.getAttribute('media')).matches;
		});
	}

	#updateRenderStatus() {
		if (this.imageLoadedCount === this.getImageCount()) {
			this.classList.add('mmx-image-across--images-loaded');
		} else {
			this.classList.remove('mmx-image-across--images-loaded');
		}
	}

	get imageLoadedCount() {
		const loadedImages = this.imageElements().filter(image => {
			const img = image?.slottedImage?.() ?? image?.shadowImage?.();
			return img?.complete;
		});

		return loadedImages.length;
	}

	updateImageHeight(size) {
		this.imageElements().forEach(image => {
			if (image.getAttribute('data-size') !== size) {
				image.setAttribute('data-size', size);
			}
		});
	}

	calculateScrollPosition()
	{
		const image_container	= this.shadowImagesContainer().scrollWidth;
		const image_position	= this.shadowImagesContainer().scrollLeft;
		const position_percent	= image_position / image_container;

		this.#scroll_position = position_percent;
	}

	setScrollPosition()
	{
		const image_container	= this.shadowImagesContainer().scrollWidth;
		const new_position 		= this.#scroll_position * image_container;

		this.shadowImagesContainer().scrollLeft	= new_position;
	}
}

if (!customElements.get('mmx-image-across')) {
	customElements.define('mmx-image-across', MMX_ImageAcross);
}